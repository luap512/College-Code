# Paul Perez
# OCTOBER 26 2021
# EXAM TWO PROJECT
# COMPLETED
#---------------------------------------------------------------------------------
# Write a program to help you balance your checkbook at the end of the month. The
# program should have the user enter the initial balance followed by a series of
# transactions. For each transaction, first have the user enter a transaction type. The valid
# transaction types are:
# • W – withdraw funds
# • D – deposit funds
# • E – Exit
# For checks and deposits, the user should be prompted to enter the transaction amount.
# Service Charges
# • There is a $0.25 service charge for each check written. Keep a running total of the
# service charges.
# • Service charges are not deducted from the account balance until the end of the
# month.
# • If the withdraw amount exceeds the balance, there will be $20.00 service charge,
# plus the check will not clear the bank.
# Output
# After each transaction, display
# • the command data (to confirm the transaction)
# • the resulting account balances
# • the total service charges accrued so far
# At the end of the month, deduct the service charges and print the final balance. 
# ------------------------------------------------------------------------------
# Trace


# this function runs our main objective
def main():
    header() # call the header function


    bankVal = getFloatData('\nEnter the beginning balance: $') # get initial balance
    checkCtr = 0 # count W/D
    serviceFee = 0 # service fee

    while (True):
        cmd = getStringData('SELECT TRANSACTION: ')



        if (cmd == 'W'): # withdraw funds
            checkCtr = checkCtr + 1 # count transaction
            checkVal = getFloatData('Enter WITHDRAWAL amount: $')

            if(checkVal > bankVal):# check to make sure funds are present
                serviceFee = serviceFee + 20 #20$ charge for overdraft
                bankVal = bankVal
                print('\nProcessing WITHDRAWAL for $',checkVal)# process transactions
                print('Current Balance: $',bankVal)
                print('Insufficient funds. Overdraft fee 20$')
                print('Accrued service fee: $',format(serviceFee,'.02f'))
            else:
                serviceFee = serviceFee + (.25)
                bankVal = bankVal - checkVal# withdraw funds
                print('\nProcessing WITHDRAWAL for $',checkVal)# process transactions
                print('Current Balance: $',bankVal)
                print('Accrued service fee: $',format(serviceFee,'.02f'))




        elif(cmd == 'D'): # deposit funds
            checkCtr = checkCtr + 1 # count transactions
            checkVal = getFloatData('Enter DEPOSIT Ammount: $')# get transaction value
            # serviceFee = serviceFee + (.25) {I wasnt sure if this was intentional, your example doesnt add a service fee for deposits?}
            bankVal = (bankVal + checkVal)
            print('\nProcessing DEPOSIT for $',checkVal)# process transactions
            print('Current Balance: $',bankVal)           
            print('Service Fee: $',format(serviceFee,'.02f'))
            
            
            


        else:
            print('------------------------------------------')
            print('     ===SUMMARY=== ') # exit
            print('------------------------------------------')
            print('\tCurrent Balance: $',format(bankVal,'.02f'))
            if(checkCtr == 0): # check for W/D
                print('\tService fee: $0')
                print('\tEnd of Month Balance: $',format(bankVal,'.02f'))
            else: # check for W/D
                print('\tService Charges: $',format((serviceFee),'.02f'))
                print('\tEnd of Month Balance: $',format((bankVal-serviceFee),'.02f'))
            break


    


# This function prints the header of the project
def header():
    print('--------------------------------------------------------------')
    print('------------------------EXAM TWO------------------------------')
    print('---Write a program to help you balance your checkbook---------')
    print('----------------at the end of the month-----------------------')
    print('--------------------------------------------------------------')    


        
    
# This function creates the menu    
def menu():
    print('------------------------------------------')
    print()
    print('            ==Select Transaction Type==')
    print('\t W----- WITHDRAW FUNDS')
    print('\t D----- DEPOSIT FUNDS')
    print('\t E----- EXIT')
    


# this funtion gets INT data from users
def getIntegerData(prompt):
     while (True):
        try:
            value = int(input(prompt))
            return value
            
                
        except ValueError:
            print("Oops!  Invalid number.  Try again...")



# this function gets FLOAT data from users (POSITIVE ONLY)
def getFloatData(prompt):
    while (True):
        try:
            value = float(input(prompt))

            if (value >= 0):
                return value

            else:
                print('\t\t No negative values...try again.\n')
            
                
        except ValueError:
            print("Oops!  That was no valid number.  Try again...\n")


# this function will get STRING data from users {valid commands: W, D, or E}
def getStringData(prompt):
    while (True):
        menu() # call menu
        value = input(prompt)
        value = value.upper()

        if (value in ['W', 'D', 'E']): 
            return value
        else:
            print('Invalid entry. try again')





   







main() # first line of execution, it calls function main()
print('\nEnd of Project')






