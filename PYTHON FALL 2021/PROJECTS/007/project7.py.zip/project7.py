# Paul Perez
# OCTOBER 22 2021
# Project 7
# COMPLETED
#---------------------------------------------------------------------------------
# Write a program that will display the first and last
# name entry as “initials”, “name in address book” and user name.
# ------------------------------------------------------------------------------



# this function runs our main objective
def main():
    header() # call the header function

    

    # initialize variables
    firstName = getStringData('Enter first name: ')
    lastName = getStringData('Enter last name: ')
    
 
    # Display data function
    displayData(firstName, lastName)
    





# This function prints the header of the project
def header():
    print('------------------------------------------------------------------------------')
    print('----------------------***PROJECT 6***-----------------------------------------')
    print('----Write a program that will display the first and last----------------------')
    print('---name entry as “initials”, “name in address book” and user name.------------')
    print('------------------------------------------------------------------------------')


# gets integer data from users
def getIntegerData(prompt):
     while (True):
        try:
            value = int(input(prompt))
            return value
            
                
        except ValueError:
            print("Invalid input  Try again...")

            

# gets float data from users
def getFloatData(prompt):
    while (True):
        try:
            value = float(input(prompt))
            return value
            
                
        except ValueError:
            print("Invalid input  Try again...")



# gets string data from users
def getStringData(prompt):
    while (True):
        try:
            value = str(input(prompt))
            return value
            
                
        except ValueError:
            print("Invalid input  Try again...")
    
   


# This fucntion displays the list
def displayData(firstName, lastName):
    print('\n')
    print('========RESULT========')
    print('INITIALS: ',firstName[0].upper() + '.' + lastName[0].upper()) # formatting commands
    print('ADDRESS BOOK: ',firstName[0].upper() + firstName[1:], lastName.upper())
    print('USERNAME: ',firstName[0] + lastName.lower())
    
   
    
    
    
    


    
    

main() # first line of execution, it calls function main()
print('\nEnd of Project')






