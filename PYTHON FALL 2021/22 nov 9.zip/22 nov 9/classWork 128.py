# AllyBaba
# Nov 9, 2021
# Class Work 126
# WIP
# -----------------------------------------------------
# -----------------------------------------------------
# Trace 19-8-9(12)-10(13) -12-15-16(12+13=25)-12-13-20
def main():
    a = int(input('Enter an integer: '))
    b = int(input('Enter an integer: '))

    result = calculate(a,b)
    print(result)

def calculate(a, b):
    return a + b


main() 
print('\nEnd of project')
